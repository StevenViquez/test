<!DOCTYPE html>

<html lang="es">

    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>

    <body>
        <header>
            <h1>Hola</h1>
        </header>
        <section>
            <article>
                <h2>Mi pagina dinamica</h2>
            </article>
            <img src="images.png">
            <form action="dinamica.php" method="post">
                <p>Su nombre: <input type="text" name="nombre" /></p>
                <p><input type="submit" /></p>
            </form>
        </section>
        <footer>

        </footer>
    </body>
</html>