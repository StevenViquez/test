<!DOCTYPE html>

<html lang="es">

    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>

    <body>
        <header>
            <h1>Pagina Dinamica</h1>
        </header>
          <?php
            if ($_POST['nombre'] == "steven") {
                echo "Hola Steven";
            } elseif ($_POST['nombre'] == "karla") {
                echo "Hola Karla";
            } else {
                echo "Hola desconocido";
            }
        ?>
        <footer>
            <p>Pagina test</p>
        </footer>
    </body>
</html>